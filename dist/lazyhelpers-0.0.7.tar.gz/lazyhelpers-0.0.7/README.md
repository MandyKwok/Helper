# Helper

A cheatsheet of handy functions that improve your productivity.

__.py:__ Contain all functions by categories.
- visualization.py
<br />

__.ipynb:__ Demonstrate the functionalities with dummy data.
- visualization.ipynb
